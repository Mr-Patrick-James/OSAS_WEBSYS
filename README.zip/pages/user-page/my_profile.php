<!-- My Profile Page -->
<main>
    <div class="head-title">
      <div class="left">
        <h1>My Profile</h1>
        <ul class="breadcrumb">
          <li>
            <a href="#">Dashboard</a>
          </li>
          <li><i class='bx bx-chevron-right'></i></li>
          <li>
            <a class="active" href="#">My Profile</a>
          </li>
        </ul>
      </div>
      <button class="btn-download" onclick="editProfile()">
        <i class='bx bxs-edit'></i>
        <span class="text">Edit Profile</span>
      </button>
    </div>
  
    <!-- Profile Information -->
    <div class="profile-container">
      <div class="profile-card">
        <div class="profile-header">
          <div class="profile-avatar">
            <img src="../assets/img/user.jpg" alt="Profile Picture" id="profilePicture">
            <button class="change-photo-btn" onclick="changeProfilePicture()">
              <i class='bx bxs-camera'></i>
            </button>
          </div>
          <div class="profile-info">
            <h2 id="userName">John Doe</h2>
            <p id="userRole">Student</p>
            <p id="studentId">Student ID: 2024-001</p>
            <div class="profile-status">
              <span class="status-badge good">Good Standing</span>
            </div>
          </div>
        </div>
      </div>
  
      <!-- Personal Information -->
      <div class="info-section">
        <div class="section-header">
          <h3><i class='bx bxs-user'></i> Personal Information</h3>
          <button class="edit-btn" onclick="editPersonalInfo()">
            <i class='bx bxs-edit'></i> Edit
          </button>
        </div>
        <div class="info-grid">
          <div class="info-item">
            <label>Full Name:</label>
            <span id="fullName">John Doe</span>
          </div>
          <div class="info-item">
            <label>Student ID:</label>
            <span id="studentIdValue">2024-001</span>
          </div>
          <div class="info-item">
            <label>Email:</label>
            <span id="email">john.doe@student.edu</span>
          </div>
          <div class="info-item">
            <label>Phone:</label>
            <span id="phone">+1 (555) 123-4567</span>
          </div>
          <div class="info-item">
            <label>Date of Birth:</label>
            <span id="dateOfBirth">January 15, 2005</span>
          </div>
          <div class="info-item">
            <label>Gender:</label>
            <span id="gender">Male</span>
          </div>
        </div>
      </div>
  
      <!-- Academic Information -->
      <div class="info-section">
        <div class="section-header">
          <h3><i class='bx bxs-graduation'></i> Academic Information</h3>
          <button class="edit-btn" onclick="editAcademicInfo()">
            <i class='bx bxs-edit'></i> Edit
          </button>
        </div>
        <div class="info-grid">
          <div class="info-item">
            <label>Department:</label>
            <span id="department">Computer Science</span>
          </div>
          <div class="info-item">
            <label>Year Level:</label>
            <span id="yearLevel">3rd Year</span>
          </div>
          <div class="info-item">
            <label>Section:</label>
            <span id="section">CS-3A</span>
          </div>
          <div class="info-item">
            <label>Advisor:</label>
            <span id="advisor">Prof. Sarah Wilson</span>
          </div>
          <div class="info-item">
            <label>Enrollment Date:</label>
            <span id="enrollmentDate">August 2022</span>
          </div>
          <div class="info-item">
            <label>Expected Graduation:</label>
            <span id="graduationDate">May 2025</span>
          </div>
        </div>
      </div>
  
      <!-- Violation Summary -->
      <div class="info-section">
        <div class="section-header">
          <h3><i class='bx bxs-shield-x'></i> Violation Summary</h3>
        </div>
        <div class="violation-summary-cards">
          <div class="summary-card">
            <div class="card-icon improper-uniform">
              <i class='bx bxs-t-shirt'></i>
            </div>
            <div class="card-content">
              <h4>Improper Uniform</h4>
              <p class="count">1 violation</p>
              <p class="last-violation">Last: 2 weeks ago</p>
            </div>
          </div>
          <div class="summary-card">
            <div class="card-icon improper-footwear">
              <i class='bx bxs-shoe'></i>
            </div>
            <div class="card-content">
              <h4>Improper Footwear</h4>
              <p class="count">1 violation</p>
              <p class="last-violation">Last: 1 month ago</p>
            </div>
          </div>
          <div class="summary-card">
            <div class="card-icon no-id">
              <i class='bx bxs-id-card'></i>
            </div>
            <div class="card-content">
              <h4>No ID Card</h4>
              <p class="count">1 violation</p>
              <p class="last-violation">Last: 3 weeks ago</p>
            </div>
          </div>
        </div>
      </div>
  
      <!-- Contact Information -->
      <div class="info-section">
        <div class="section-header">
          <h3><i class='bx bxs-phone'></i> Contact Information</h3>
          <button class="edit-btn" onclick="editContactInfo()">
            <i class='bx bxs-edit'></i> Edit
          </button>
        </div>
        <div class="info-grid">
          <div class="info-item">
            <label>Address:</label>
            <span id="address">123 University Ave, City, State 12345</span>
          </div>
          <div class="info-item">
            <label>Emergency Contact:</label>
            <span id="emergencyContact">Jane Doe (Mother) - +1 (555) 987-6543</span>
          </div>
          <div class="info-item">
            <label>Guardian:</label>
            <span id="guardian">Robert Doe (Father)</span>
          </div>
        </div>
      </div>
    </div>
  
    <!-- Edit Profile Modal -->
    <div id="editModal" class="modal" style="display: none;">
      <div class="modal-content">
        <div class="modal-header">
          <h3 id="modalTitle">Edit Information</h3>
          <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        <div class="modal-body">
          <form id="editForm">
            <div class="form-group">
              <label for="editFullName">Full Name:</label>
              <input type="text" id="editFullName" name="fullName">
            </div>
            <div class="form-group">
              <label for="editEmail">Email:</label>
              <input type="email" id="editEmail" name="email">
            </div>
            <div class="form-group">
              <label for="editPhone">Phone:</label>
              <input type="tel" id="editPhone" name="phone">
            </div>
            <div class="form-group">
              <label for="editAddress">Address:</label>
              <textarea id="editAddress" name="address" rows="3"></textarea>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" onclick="closeEditModal()">Cancel</button>
          <button class="btn-save" onclick="saveProfile()">Save Changes</button>
        </div>
      </div>
    </div>
  </main>
  
  <script>
  // Load user profile data
  document.addEventListener('DOMContentLoaded', function() {
    loadUserProfile();
  });
  
  function loadUserProfile() {
    // Get user session data
    const userSession = localStorage.getItem('userSession');
    if (userSession) {
      const session = JSON.parse(userSession);
      
      // Update profile information
      document.getElementById('userName').textContent = session.name;
      if (session.studentId) {
        document.getElementById('studentId').textContent = `Student ID: ${session.studentId}`;
        document.getElementById('studentIdValue').textContent = session.studentId;
      }
    }
  }
  
  function editProfile() {
    showEditModal('Edit Profile', 'personal');
  }
  
  function editPersonalInfo() {
    showEditModal('Edit Personal Information', 'personal');
  }
  
  function editAcademicInfo() {
    showEditModal('Edit Academic Information', 'academic');
  }
  
  function editContactInfo() {
    showEditModal('Edit Contact Information', 'contact');
  }
  
  function showEditModal(title, type) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('editModal').style.display = 'block';
    
    // Populate form based on type
    if (type === 'personal') {
      document.getElementById('editFullName').value = document.getElementById('fullName').textContent;
      document.getElementById('editEmail').value = document.getElementById('email').textContent;
      document.getElementById('editPhone').value = document.getElementById('phone').textContent;
    } else if (type === 'contact') {
      document.getElementById('editAddress').value = document.getElementById('address').textContent;
    }
  }
  
  function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
  }
  
  function saveProfile() {
    // Get form data
    const formData = new FormData(document.getElementById('editForm'));
    
    // Update profile information
    if (formData.get('fullName')) {
      document.getElementById('fullName').textContent = formData.get('fullName');
      document.getElementById('userName').textContent = formData.get('fullName');
    }
    if (formData.get('email')) {
      document.getElementById('email').textContent = formData.get('email');
    }
    if (formData.get('phone')) {
      document.getElementById('phone').textContent = formData.get('phone');
    }
    if (formData.get('address')) {
      document.getElementById('address').textContent = formData.get('address');
    }
    
    // Show success message
    showNotification('Profile updated successfully!', 'success');
    closeEditModal();
  }
  
  function changeProfilePicture() {
    showNotification('Profile picture upload feature coming soon!', 'info');
  }
  
  // Close modal when clicking outside
  window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  }
  </script>