<!-- Announcements Page -->
<main>
    <div class="head-title">
      <div class="left">
        <h1>Announcements</h1>
        <ul class="breadcrumb">
          <li>
            <a href="#">Dashboard</a>
          </li>
          <li><i class='bx bx-chevron-right'></i></li>
          <li>
            <a class="active" href="#">Announcements</a>
          </li>
        </ul>
      </div>
      <div class="announcement-actions">
        <button class="btn-mark-all-read" onclick="markAllAsRead()">
          <i class='bx bxs-check-circle'></i>
          <span class="text">Mark All Read</span>
        </button>
        <button class="btn-refresh" onclick="refreshAnnouncements()">
          <i class='bx bx-refresh'></i>
          <span class="text">Refresh</span>
        </button>
      </div>
    </div>
  
    <!-- Filter and Search -->
    <div class="announcement-filters">
      <div class="filter-group">
        <label for="categoryFilter">Category:</label>
        <select id="categoryFilter" onchange="filterAnnouncements()">
          <option value="all">All Categories</option>
          <option value="urgent">Urgent</option>
          <option value="policy">Policy Updates</option>
          <option value="event">Events</option>
          <option value="general">General</option>
        </select>
      </div>
      <div class="filter-group">
        <label for="statusFilter">Status:</label>
        <select id="statusFilter" onchange="filterAnnouncements()">
          <option value="all">All Status</option>
          <option value="unread">Unread</option>
          <option value="read">Read</option>
        </select>
      </div>
      <div class="search-group">
        <input type="text" id="searchInput" placeholder="Search announcements..." onkeyup="searchAnnouncements()">
        <button class="search-btn" onclick="searchAnnouncements()">
          <i class='bx bx-search'></i>
        </button>
      </div>
    </div>
  
    <!-- Announcements List -->
    <div class="announcements-list">
      <!-- Urgent Announcement -->
      <div class="announcement-card urgent unread" data-category="urgent">
        <div class="announcement-header">
          <div class="announcement-icon urgent">
            <i class='bx bxs-error-circle'></i>
          </div>
          <div class="announcement-title">
            <h3>Important: New Dress Code Policy</h3>
            <div class="announcement-meta">
              <span class="announcement-date">2 hours ago</span>
              <span class="announcement-category urgent">Urgent</span>
            </div>
          </div>
          <div class="announcement-actions">
            <button class="btn-mark-read" onclick="markAsRead(this)" style="display: block;">
              <i class='bx bxs-check-circle'></i>
            </button>
          </div>
        </div>
        <div class="announcement-content">
          <p>Effective immediately, all students must wear proper uniform and footwear. ID cards are mandatory at all times. Please review the updated guidelines in the student handbook.</p>
          <div class="announcement-tags">
            <span class="tag">Dress Code</span>
            <span class="tag">Policy</span>
          </div>
        </div>
      </div>
  
      <!-- Policy Update -->
      <div class="announcement-card policy read" data-category="policy">
        <div class="announcement-header">
          <div class="announcement-icon policy">
            <i class='bx bxs-info-circle'></i>
          </div>
          <div class="announcement-title">
            <h3>ID Card Replacement Schedule</h3>
            <div class="announcement-meta">
              <span class="announcement-date">1 day ago</span>
              <span class="announcement-category policy">Policy</span>
            </div>
          </div>
          <div class="announcement-actions">
            <button class="btn-mark-read" onclick="markAsRead(this)" style="display: none;">
              <i class='bx bxs-check-circle'></i>
            </button>
          </div>
        </div>
        <div class="announcement-content">
          <p>Students who have lost their ID cards can get replacements every Tuesday and Thursday from 9 AM to 3 PM at the Student Services Office. Bring a valid ID and pay the replacement fee.</p>
          <div class="announcement-tags">
            <span class="tag">ID Card</span>
            <span class="tag">Services</span>
          </div>
        </div>
      </div>
  
      <!-- Event Announcement -->
      <div class="announcement-card event unread" data-category="event">
        <div class="announcement-header">
          <div class="announcement-icon event">
            <i class='bx bxs-calendar'></i>
          </div>
          <div class="announcement-title">
            <h3>Student Orientation Week</h3>
            <div class="announcement-meta">
              <span class="announcement-date">3 days ago</span>
              <span class="announcement-category event">Event</span>
            </div>
          </div>
          <div class="announcement-actions">
            <button class="btn-mark-read" onclick="markAsRead(this)" style="display: block;">
              <i class='bx bxs-check-circle'></i>
            </button>
          </div>
        </div>
        <div class="announcement-content">
          <p>Join us for Student Orientation Week from January 22-26, 2024. Various activities and workshops will be held throughout the week. Registration is required.</p>
          <div class="announcement-tags">
            <span class="tag">Orientation</span>
            <span class="tag">Events</span>
          </div>
        </div>
      </div>
  
      <!-- General Announcement -->
      <div class="announcement-card general read" data-category="general">
        <div class="announcement-header">
          <div class="announcement-icon general">
            <i class='bx bxs-bell'></i>
          </div>
          <div class="announcement-title">
            <h3>Library Hours Update</h3>
            <div class="announcement-meta">
              <span class="announcement-date">1 week ago</span>
              <span class="announcement-category general">General</span>
            </div>
          </div>
          <div class="announcement-actions">
            <button class="btn-mark-read" onclick="markAsRead(this)" style="display: none;">
              <i class='bx bxs-check-circle'></i>
            </button>
          </div>
        </div>
        <div class="announcement-content">
          <p>The library will now be open until 10 PM on weekdays and 6 PM on weekends. Extended hours are available during exam periods.</p>
          <div class="announcement-tags">
            <span class="tag">Library</span>
            <span class="tag">Hours</span>
          </div>
        </div>
      </div>
  
      <!-- System Maintenance -->
      <div class="announcement-card general unread" data-category="general">
        <div class="announcement-header">
          <div class="announcement-icon general">
            <i class='bx bxs-cog'></i>
          </div>
          <div class="announcement-title">
            <h3>System Maintenance Scheduled</h3>
            <div class="announcement-meta">
              <span class="announcement-date">2 weeks ago</span>
              <span class="announcement-category general">General</span>
            </div>
          </div>
          <div class="announcement-actions">
            <button class="btn-mark-read" onclick="markAsRead(this)" style="display: block;">
              <i class='bx bxs-check-circle'></i>
            </button>
          </div>
        </div>
        <div class="announcement-content">
          <p>The OSAS system will undergo maintenance on Sunday, 2:00 AM - 4:00 AM. Please plan accordingly and save your work before the maintenance window.</p>
          <div class="announcement-tags">
            <span class="tag">System</span>
            <span class="tag">Maintenance</span>
          </div>
        </div>
      </div>
    </div>
  
    <!-- Load More Button -->
    <div class="load-more-container">
      <button class="btn-load-more" onclick="loadMoreAnnouncements()">
        <i class='bx bx-plus'></i>
        <span>Load More Announcements</span>
      </button>
    </div>
  </main>
  
  <script>
  // Filter announcements
  function filterAnnouncements() {
    const categoryFilter = document.getElementById('categoryFilter').value;
    const statusFilter = document.getElementById('statusFilter').value;
    const announcements = document.querySelectorAll('.announcement-card');
    
    announcements.forEach(announcement => {
      const category = announcement.getAttribute('data-category');
      const isRead = announcement.classList.contains('read');
      
      let showAnnouncement = true;
      
      // Filter by category
      if (categoryFilter !== 'all' && category !== categoryFilter) {
        showAnnouncement = false;
      }
      
      // Filter by status
      if (statusFilter === 'read' && !isRead) {
        showAnnouncement = false;
      } else if (statusFilter === 'unread' && isRead) {
        showAnnouncement = false;
      }
      
      announcement.style.display = showAnnouncement ? 'block' : 'none';
    });
  }
  
  // Search announcements
  function searchAnnouncements() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const announcements = document.querySelectorAll('.announcement-card');
    
    announcements.forEach(announcement => {
      const title = announcement.querySelector('h3').textContent.toLowerCase();
      const content = announcement.querySelector('.announcement-content p').textContent.toLowerCase();
      
      if (title.includes(searchTerm) || content.includes(searchTerm)) {
        announcement.style.display = 'block';
      } else {
        announcement.style.display = 'none';
      }
    });
  }
  
  // Mark announcement as read
  function markAsRead(button) {
    const announcement = button.closest('.announcement-card');
    announcement.classList.remove('unread');
    announcement.classList.add('read');
    button.style.display = 'none';
    
    // Update unread count
    updateUnreadCount();
    
    showNotification('Announcement marked as read', 'success');
  }
  
  // Mark all announcements as read
  function markAllAsRead() {
    const unreadAnnouncements = document.querySelectorAll('.announcement-card.unread');
    
    unreadAnnouncements.forEach(announcement => {
      announcement.classList.remove('unread');
      announcement.classList.add('read');
      const markButton = announcement.querySelector('.btn-mark-read');
      if (markButton) {
        markButton.style.display = 'none';
      }
    });
    
    updateUnreadCount();
    showNotification('All announcements marked as read', 'success');
  }
  
  // Update unread count
  function updateUnreadCount() {
    const unreadCount = document.querySelectorAll('.announcement-card.unread').length;
    const countElement = document.querySelector('.unread-count');
    if (countElement) {
      countElement.textContent = unreadCount;
    }
  }
  
  // Refresh announcements
  function refreshAnnouncements() {
    showNotification('Refreshing announcements...', 'info');
    // In a real app, this would fetch new announcements from the server
    setTimeout(() => {
      showNotification('Announcements refreshed', 'success');
    }, 1000);
  }
  
  // Load more announcements
  function loadMoreAnnouncements() {
    showNotification('Loading more announcements...', 'info');
    // In a real app, this would load additional announcements
    setTimeout(() => {
      showNotification('No more announcements to load', 'info');
    }, 1000);
  }
  
  // Initialize page
  document.addEventListener('DOMContentLoaded', function() {
    updateUnreadCount();
  });
  </script>